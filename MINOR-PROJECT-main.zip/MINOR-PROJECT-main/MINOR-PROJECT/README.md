# DISPRED

<ul>
  <li type = "square">The Project focuses on saving life of peoples , by saving time , human errors and by early prediction of diseases or infection</li>
<br>
<li type = "square">Through this application you can check whether you are experencing from Coronavirus or not , this can widely help the government to identify patients</li>
<br>
<li type = "square">There are many other feature supported by this application like DISEASE PREDICTION which predicts over 10+ Main diseases based on symptoms</li>
   
   <br>
  <table>
  <tr>
    <td>Malaria</td>
    <td>Hypertension</td>
    <td>Paralysis</td>
    <td>Pneumonia</td>
  </tr>
   <tr>
    <td>Dengue</td>
    <td>Migraine</td>
    <td>Drug Reaction</td>
    <td rowspan = 2> Dimorphic hemmorhoids(piles)</td>
  </tr>
  
  <tr>
    <td>Heart Attack</td>
    <td>Cervical spondylosis</td>
    <td>Alcoholic hepatitis</td>
  </tr>
</table>
  <br>
<li type = "square">It also predicts </li>
<li><ul>
<li type = "disc" >CHRONIC KIDNEY DISEASE</li>
<li type = "disc">HEART DISEASE</li>
<li type = "disc">DIABETES PREDICTION</li>
<li type = "disc">COVID 19</li>
</ul></li>

</ul>


### [Click here](https://github.com/ShouryaPantUnofficial/MINOR-PROJECT/tree/main/ml%20models) to view all of ML code required to build this application.

